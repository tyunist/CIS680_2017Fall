import numpy as np 

x = np.arange(4)
print x

np.delete(x,x[0])
print  x